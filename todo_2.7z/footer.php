<div class="container" >
<div class="tasks-counter">
<?php




$liczba_elementow = count($zadania);
echo "Masz $liczba_elementow zadań";
?>
</div>
</div>


<script src="assets/js/ajax.js"></script>

</body>






