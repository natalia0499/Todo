document.addEventListener("DOMContentLoaded", function() {
  // Pobranie listy zadań
  const tasks = document.querySelectorAll('.task');
  tasks.forEach(task => {
      const taskId = task.getAttribute('data-task1');
      console.log('Task ID:', taskId);
  });

  // Inny kod, np. pobieranie użytkowników
  fetch('getUsers.php')
      .then(response => response.text())
      .then(data => {
          document.getElementById('userList').innerHTML += data;
      });
});

function addTask() {
  const taskName = document.getElementById("inputZadanie").value;
  const userId = document.getElementById("userList").value;
  console.log(taskName);

  if(taskName == "" || userId == "") {
      // Obsługa błędów
  } else {
      const ajax = new XMLHttpRequest();
      ajax.onload = function() {
          document.getElementById("tasks").innerHTML = this.responseText;
          
          // Ponownie pobierz listę zadań i wyświetl identyfikatory
          const tasks = document.querySelectorAll('.task');
          tasks.forEach(task => {
              const taskId = task.getAttribute('data-task1');
              console.log('Task ID:', taskId);
          });
      };
      ajax.open("GET", "addTask.php?taskName=" + taskName + "&user_id=" + userId);
      ajax.send();
  }
}

const button = document.getElementById("button");
button.addEventListener("click", sendForm);

function sendForm() {
  const inputZadanie = document.getElementById("inputZadanie");
  const userList = document.getElementById("userList");
  let inputErrors = 0;

  if (inputZadanie.value === "") {
      inputZadanie.classList.add("error");
      inputErrors += 1;
  } else {
      inputZadanie.classList.remove("error");
  }

  if (userList.value === "") {
      userList.classList.add("error");
      inputErrors += 1;
  } else {
      userList.classList.remove("error");
  }

  if (inputErrors === 0) {
      addTask();
  }

  console.log(inputErrors);
}
