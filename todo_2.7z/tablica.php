
<?php
$zadania = [];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$user_login = 2;
$sql = "SELECT name FROM tasks WHERE user_id = 2;";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
 
    while($row = $result->fetch_assoc()) {

   array_push($zadania, $row["name"]);
    }
  } else {
    echo "0 results";
  }

?>
<div id="tasks">
<?php

foreach($zadania as $zadanie){
  require_once 'templates/task.php';
}
?>
</div>
</div>
<div class="add">
<input type="text" id="inputZadanie">

<select id="userList">
    <option value="">Wybierz użytkownika</option>
</select>
<button id="button" onclick="addTask()">Dodaj</button>

</div>