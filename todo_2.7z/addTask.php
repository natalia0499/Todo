<?php
$zadania = [];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo";
$taskName = $_GET['taskName'];
$user_id = $_GET['user_id'];

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
  echo "błąd";
    die("Connection failed: " . mysqli_connect_error());
}

$user_login = 2;
$sql = "SELECT name FROM tasks WHERE user_id = $user_id;";
$sql_addtask = "INSERT INTO `tasks`(`name`,`user_id`) VALUES ('$taskName','$user_id');";

$addtask = $conn->query($sql_addtask);


$result = $conn->query($sql);
if ($result->num_rows > 0) {
 
    while($row = $result->fetch_assoc()) {

   array_push($zadania, $row["name"]);
    }
  } else {
   
  }
  $conn->close(); 
  foreach($zadania as $zadanie){
    require('templates/task.php');
}
?>



