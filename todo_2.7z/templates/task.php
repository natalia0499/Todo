<?php
// Sprawdź, czy funkcja już istnieje
if (!function_exists('getTasksFromDatabase')) {
    function getTasksFromDatabase() {
       
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "todo"; 

        // Tworzenie połączenia
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Sprawdzanie połączenia
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        
        $sql = "SELECT id, name FROM tasks"; 
        $result = $conn->query($sql);

        // Inicjalizacja tablicy z zadaniami
        $tasks = [];

        if ($result->num_rows > 0) {
            // Pobieranie danych
            while($row = $result->fetch_assoc()) {
                $tasks[] = $row;
            }
        }

      
        $conn->close();

        return $tasks;
    }
}

// Użycie funkcji do pobrania zadań
$tasks = getTasksFromDatabase();
foreach ($tasks as $task) {
    $id_zadania = $task['id'];
    $nazwa_zadania = $task['name'];
    echo "<div class='box' data-task1='$id_zadania'>$nazwa_zadania</div>";
}
?>
