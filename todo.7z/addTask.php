
<?php
$zadania = [];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "todo";
$taskName = $_GET['taskName'];

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
  echo "błąd";
    die("Connection failed: " . mysqli_connect_error());
}

$user_login = 2;
$sql = "SELECT name FROM tasks WHERE user_id = 2;";
$sql_addtask = "INSERT INTO `tasks`(`name`,`user_id`) VALUES ('$taskName', $user_id);";
$sql_users = "SELECT id, name FROM users;";
$result_users = $conn->query($sql_users);
$users = [];
if ($result_users->num_rows > 0) {
    while($row = $result_users->fetch_assoc()) {
        $users[] = $row;
    }
}
if(isset($_GET['user_id'])) {
  $user_id = $_GET['user_id'];
  $sql = "SELECT name FROM tasks WHERE user_id = $user_id;";
} else{

}

$addtask = $conn->query($sql_addtask);



$result = $conn->query($sql);
if ($result->num_rows > 0) {
 
    while($row = $result->fetch_assoc()) {

   array_push($zadania, $row["name"]);
    }
  } else {
    echo "0 results";
  }

?>

<?php

foreach($zadania as $zadanie){
    require('templates/task.php');
}

