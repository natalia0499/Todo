<div class="container" >
<div class="tasks-counter">
<?php
//include 'tablica.php';
$liczba_elementow = count($zadania);
echo "Masz $liczba_elementow zadań";
?>
</div>
</div>
<select id="userList" onchange="changeUser()">
    <option value="">Wybierz użytkownika</option>
    <?php
    foreach ($users as $user) {
        echo "<option value='".$user['id']."'>".$user['name']."</option>";
    }
    ?>
</select>

<script src="assets/js/ajax.js"></script>
</body>






