<?php 
echo '<div class="box">' . $zadanie .  "</div>";
?>


