document.addEventListener("DOMContentLoaded", function() {
  // Pobranie listy użytkowników z serwera
  fetch('getUsers.php')
      .then(response => response.text())
      .then(data => {
          document.getElementById('userList').innerHTML += data;
      });
});
function addTask() {

    const taskName = document.getElementById("inputZadanie").value;
    const userId = document.getElementById("userList").value;
    console.log(taskName);
   
    if(taskName == "" || userId == ""){

    } else {
      const ajax = new XMLHttpRequest();
      ajax.onload = function () {
        document.getElementById("tasks").innerHTML = this.responseText;
  
      };
      ajax.open(
        "GET",
        "addTask.php?taskName=" + taskName + "&user_id=" + userId
      );
      ajax.send();

    }


    
}
document.addEventListener("DOMContentLoaded", function() {
  loadUsers();
  loadTasks(1); 
});


