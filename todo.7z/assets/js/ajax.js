


/*let addTaskButton = document.getElementById("button");
let addTaskInput = document.getElementById("inputZadanie");
function addTask(){
    if( addTaskInput.value == ""){
        console.log("test");
        addTaskInput.classList.add("error");
    } else{
        console.log("test2");

    }
 
}*/
//addTaskButton.addEventListener("click", addTask);
function addTask() {

    const taskName = document.getElementById("inputZadanie").value;
    console.log(taskName);
   
    if(taskName == ""){

    } else {
      const ajax = new XMLHttpRequest();
      ajax.onload = function () {
        document.getElementById("tasks").innerHTML = this.responseText;
  
      };
      ajax.open(
        "GET",
        "addTask.php?taskName=" + taskName + "&user_id=" + userId
      );
      ajax.send();

    }

    
}
function changeUser() {
  const userId = document.getElementById("userList").value;
  const ajax = new XMLHttpRequest();
  ajax.onload = function () {
      document.getElementById("tasks").innerHTML = this.responseText;
  };
  ajax.open(
      "GET",
      "addTask.php?user_id=" + userId
  );
  ajax.send();
}
   
    
  

/*
1 = 1
1 == "1"
1 = "1"
*/
// zmien klasy na angielskie
/*
zmienić element header i footer na div z klasami heading i tasks-counter
wszystkie elementy wrzuci w jeden kontener z klasą container i ostylować tak by wyglądało wszystko tak jak przed zmianami jednocześnie usuwająć niepotrzebne style
*/